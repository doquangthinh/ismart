<div id="footer-wp">
    <div class="wp-inner">
        <p id="copyright">2018 © Admin Theme by Php Master</p>
    </div>
</div>
</div>
</div>
</body>
</html>