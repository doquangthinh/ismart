<?php
get_header();
?>


<div id="content">
    <h1>đơn hàng</h1>
    <button id="check_ajax"  data-id="150"> check ajax</button>
</div>


<?php
get_footer();
?>

