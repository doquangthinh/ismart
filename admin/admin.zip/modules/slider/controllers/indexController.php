<?php

function construct() {
    load_model('index');
}

function add_sliderAction() {
   load_view('index');
}

function list_sliderAction() {
    load_view('list_slider');
}

