<?php
get_header();
?>


<div id="main-content-wp" class="add-cat-page">
    <div class="wrap clearfix">
        <?php get_sidebar(); ?>
        <div id="content" class="fl-right">
            
            <div class="section" id="title-page">
                <div class="clearfix">
                    <h3 id="index" class="fl-left">Thêm sản phẩm thành công</h3> <br> 
                    <h3>  click vào <a href="?mod=products&action=add_product">đây</a> để tiếp tục </h3>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php
get_footer();
?>