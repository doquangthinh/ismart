<?php

function construct() {

}

function indexAction() {
   load_view('index');
}

function addAction() {
    
}

function editAction() {
   
}

function mainAction(){
    echo 'bài viết';
}
