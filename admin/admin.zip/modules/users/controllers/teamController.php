<?php 

function construct()
{
    load_model('index');
}


function indexAction(){
    load_view('teamIndex');
}