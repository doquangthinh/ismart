<?php

function construct() {
    load_model('index');
}

function list_mediaAction() {
   load_view('index');
}

