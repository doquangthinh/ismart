<?php

function construct() {
    load_model('index');
}

function indexAction() {
   load_view('index');
}

function addAction() {
    
}

function editAction() {
   
}

function datetimeAction(){
    echo 'test action';
}
